# Rosoto 更新日志（CHANGELOG）

> 产品后端 = 自研后端（Linux x86_64 ELF / Windows PE32+ / AArch64）；
> C99 后端仅作交叉验证。格式：每版本记录「特性 / 优化 / 修复 / 回归规模」。

---

## v0.9 — 2026-10-20 性能轮（工作区，待提交）

**基准**（Xeon E5-2666 v3 / WSL2 / gcc 15.2，`tests/bench.sh` best-of-3）：

| 基准 | v0.8 自研 | **v0.9 自研** | gcc -O2 / pthread | 原目标 |
|---|---|---|---|---|
| loop_sum 2 亿热循环 | 380–518 ms | **11–13 ms** | 231 ms | 80 ms ✅ |
| parfor_sum 6M 任务 / 3 核 | 388–620 ms | **29–35 ms** | 131 ms | 50 ms ✅ |

### 优化

- **模块级数求和折叠 `opt_modsum`（新 pass，`tools/rosoto_opt.py`）**
  规范归约循环 `acc += (x0 + s·j) mod D`（gcd(s,D)=1 且 x 非负已证）整体折叠：
  - 整周期块：任意连续 U=D 项余数是 0..D-1 的排列 ⇒ 每块贡献常量 `D(D-1)/2`，
    `B = N//U` 块直接折叠成 `acc += B·D(D-1)/2`（N 编译期常量时继续常量折叠）；
  - 尾部 R<U 项：s=1 走无除法闭式 `R·tB + R(R-1)/2 − D·max(0, tB+R−D)`；
    s>1 保留只跑 R 次的 peel 小循环；
  - 归约按 2^64 环面同态，回绕语义与逐项累加严格一致。
  - 边界：gcd(s,D)>1 / 迭代数非编译期常量 / x 非负不可证 → 整体放弃，语义不变。
- **范围分析扩展（`analyze_nonneg` + `lower_parfor`）**
  - parfor worker 形参范围：clone() 调用点均为编译期常量块界 → `arg_ranges` 元数据；
  - `for` 形态 `jcc ge` 守卫与 `while` 形态统一按 `i < hi` 做上界证明；
  - 双 vreg 加法传播（如 `i*C + k`）、形参初始化归纳变量；
  - 效果：worker 热循环里有符号魔数除法的双重符号修正链整体消除（parfor 原 4 倍差距的主因）。
- **乘常数编码修复（`tools/rosoto_native.py`，潜伏 bug）**
  `mul_const` 回退路径（lea 链规划失败时）曾把 `x*C` 静默编码成 `x*x`——常数被丢弃。
  新增 `Enc.imul_rri`（三操作数 `imul r64, r64, imm32`）修正；历史上任何
  lea 链规划不下的常量乘法都会错编，本轮由 modsum 闭式代码首次触发并修复。

### 验证

- 回归 **198 项全绿**：Windows PE 61 / 自研 Linux 61 / C 16 / corelib 34 / io_uring 26（本地 + 机器上各跑一遍）；
- modsum 差分模糊 **180 例**：优化 ≡ 无优化 ≡ Python 真值（含负值门控组，覆盖放弃路径）。

### 未发布（工作区既有内容，随本轮一起进入快照）

- `result[T,E]` 泛型单态化 + `?` 传播 + match 解构（回归 [14]，三链全绿）；
- `[]T` 切片：{ptr,len} 两字零拷贝视图 + 聚合 ABI + 动态越界 fail-fast（回归 [15]，三链全绿）。

---

## v0.8 — 2026-10-19 19:59 `option[T]` 受控单态化

- `option[int/bool/str]` 跨 native / Windows PE / C 三链：`option[T].some(x)/.none()` 构造、
  `Option.Some(v)/Option.None` match 解构、函数返回 `option[T]`（复用枚举聚合 ABI）。
- 实现 = 前端合成真枚举 `__opt_<T>` + 构造脱糖 `enumlit` + 模式按求值式真实枚举名改写；后端零改动。
- 回归 187 项全绿（Windows 57 / native 54 / C 16 / corelib 34 / io_uring 26）。

## v0.7 — 2026-10-19 18:21 Result 错误传播 + 保守范围分析

- 用户定义 `Result` 枚举 + `?` 传播三链打通；`Ok` tag 按声明顺序取，不再硬编码 0。
- 自研优化器：严格递增常量上界循环的非负范围传播，安全消除有符号魔数除法符号修正链；
  parfor/spawn worker 保留 `no_inline` 寄存器分配边界。
- 回归 183 项全绿。

## v0.6 — 2026-10-19 14:29 定长数组 `[N]T`

- 帧上连续 N 字、动态下标、值语义拷贝、越界 fail-fast（`bounds_check` 编译期开关）。
- 数组作参数/返回值明确报错（切片见未发布项）。回归 180 项全绿。

## v0.5 — 2026-10-19 14:22 `chan[T]` 有界 MPMC 通道

- 48 字节控制块 + `xchg` 自旋锁 + yield；C 后端条件变量等价实现。
- 运行库按需发射：只用到的 arena/join/chan 才进产物。回归 172 项全绿。

## v0.4 — 2026-10-19 13:46 `spawn`/`join` 任务并行 + arena 帧级回收

- `spawn f(args)` + `join(h)`；Linux raw `clone()` / Windows `CreateThread` / C pthread。
- arena 回卷 bump 指针，块内分配一次性回收。回归 165 项全绿。

## v0.3 — 2026-10-19 13:01 自研 Windows x86_64 PE/COFF 后端

- 同一 RosIR → PE32+ / COFF + kernel32 导入 + DIR64 重定位，无 CRT，产物 6–26 KB。
- 回归 152 项全绿。

## v0.1–v0.2（此前）

- v0.1：Rosoto → RosIR → 优化 passes → 线性扫描寄存器分配 → 自研指令编码器 → 裸 ELF64；
  魔数除法（mulhi+移位）、常量折叠、复制传播、DCE、cmp+jcc 融合、帧槽复用。
- v0.2：RosIR 优化器成型（LICM / CSE / 循环展开 / 指令调度 / 强度削减）、内联、
  运行库 RosIR 自举（print/itoa/strlen/alloc）。

---

*维护约定：性能改动必须附 `tests/bench.sh` 基线对比 + 全量回归数字；
优化 pass 不满足证明条件时必须安全放弃，语义等价由 C 后端交叉验证兜底。*
