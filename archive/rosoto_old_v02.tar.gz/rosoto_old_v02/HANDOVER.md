# Rosoto 交接文档（HANDOVER）

> 本轮：**v0.2 语言核心补全 + 双后端/三发射层同步 + 全量回归**
> 交接时间：2026-10-19（GMT+8）
> 状态：**全部测试绿**（109 项：原生 33 / C 16 / 核心运行库 34 / io_uring 26）
> 代码总量：`tools/` 9824 行 Python + `tests/` 1000 行脚本/模拟器 + 165 行 `.ros` 测试与示例

---

## 1. 这一轮做了什么

### 1.1 语言层：新增 `break` / `continue` / `struct`（三后端全部打通）

| 能力 | 语法 | 自研 x86_64 | 自研 AArch64 | C 后端 |
|---|---|---|---|---|
| `break` / `continue` | 循环内跳转 | ✅ | ✅ | ✅ |
| `struct` 声明 | `struct Vec3 { x: int y: int z: int }` | ✅ | ✅ | ✅ |
| 结构体字面量 | `Vec3 { x: 1, y: 2, z: 3 }` | ✅ | ✅ | ✅ |
| 字段读 / 写 / 复合赋值 | `a.x` / `a.x = 10` / `a.y += 5` | ✅ | ✅ | ✅ |
| 嵌套结构体 | `Body { pos: Vec3, mass: int }` → `body.pos.y = 42` | ✅ | ✅ | ✅ |
| **值语义拷贝** | `let b = a` 拷贝；`f(b)` 传副本，副作用不外泄 | ✅ | ✅ | ✅ |
| 字段访问链 | `v.x.y` / 调用结果取字段 `get().x` | ✅ | ✅ | ✅ |
| `assert(cond, "msg")` | 内建自校验（UTF-8 字节长度已修正） | ✅ | ✅ | ✅ |

**值语义是刻意对齐 C 的**：`fn rebalance(it: Item, ...)` 里改 `it.value` 不会改到调用方
（自研后端由调用方把结构体拷到临时帧槽再传地址，C 后端天然是按值传参）。

### 1.2 自研后端新增 RosIR 指令 `frameaddr`

```
('frameaddr', dst, word)   dst = &帧上结构体区[word]
```

- 帧布局：`[rbp-8 … rbp-8*nslots]` 是寄存器溢出槽，其下整段是结构体局部区
- **x86_64 与 AArch64 发射层各自实现**，优化器（`rosoto_opt.py`）/内联/寄存器分配全共享
- 结构体局部量走**栈帧**而非全局静态区 → 递归安全、可重入、多线程安全

### 1.3 本轮修复的 3 个真实缺陷（都有回归用例）

| # | 症状 | 根因 | 修复 | 回归用例 |
|---|---|---|---|---|
| 1 | `struct` + `parfor` 同函数时归约结果错乱（跨 run 数值还不稳定） | `opt_inline` 把 parfor worker 内联进父函数；worker 跑在 `clone()` 出来的**另一个栈**上，内联后其溢出槽/帧槽落到**父栈帧**，子线程写进去砸坏父线程活跃值 | worker 标记 `no_inline`；内联时 `frameaddr` 字号整体搬迁 | `tests/t10.ros` |
| 2 | 字段读到错误的值；严重时写穿到保存的 rbp / 返回地址 | `frameaddr` 把字序号映射成**地址递减**，而 `load/store` 是 `base + idx*8` **递增**寻址，方向相反 → 字段反向错位 | 统一为「字序号递增 == 地址递增」，两发射层同步改 | `tests/t11.ros` |
| 3 | `for i in 0..crate.count {` 被误判成结构体字面量（`{` 被吃掉） | 单段/多段点路径一律当成类型路径 | 类型路径判据 = 末段是已声明 struct **或** 限定路径且末段大写（SPEC §1 PascalCase） | `examples/inventory.ros` |

> 另修：`assert` 失败消息的 `write()` 长度此前按**字符数**算，中文消息被截断 → 改按 UTF-8 **字节数**。

### 1.4 新写的示例（自己举例，全部带 `assert` 自校验）

| 文件 | 主线 | 覆盖 |
|---|---|---|
| `examples/game_loop.ros` | **游戏** | Vec3/Body 嵌套结构体、帧循环、帧预算 `break`、`continue` 跳过统计、`parfor` 动能归约、按值传参不外泄 |
| `examples/collatz.ros` | **算法/性能** | 迭代链长、`while` + `break`/`continue`、10 万级热循环 |
| `examples/inventory.ros` | **工程建模** | Item/Crate 嵌套结构体、字段复合赋值、破损跳过、命中即 `break`、值语义断言 |
| `examples/prime_parallel.ros` | **多核** | `parfor` + `+=` 归约、`is_prime` 函数调用、`cores()` |

每个示例在**自研 x86_64 / 自研 AArch64 / C 后端**三条链上输出逐字节一致。

### 1.5 回归扩容

- `tests/run_native_tests.sh`：15 项 → **33 项**（新增 [8] break/continue+struct 三后端交叉验证、[9] 新示例自校验、[10] AArch64 `frameaddr` 执行级验证）
- `tests/run_tests.sh`：8 项 → **16 项**（新增 [5] v0.2 语言特性自校验）
- 合计 **109 项全绿**（corelib 34 + uring 26 不变）

---

## 2. 还没有做什么（未完成清单）

### 2.1 语言特性（SPEC 已写、编译器未实现）

| 特性 | SPEC 出处 | 现状 | 优先级 |
|---|---|---|---|
| `enum` + `match`（含穷尽性检查） | §2 / §3 | ❌ 未实现 | **高**（语言辨识度） |
| `option[T]` / `result[T,E]` + `?` 传播 | §2 / §3 | ❌ `?` 只在 C 后端 echo 场景有占位；自研后端直接报错 | 高 |
| `map[K]V`、`[N]T` 定长数组、`[]T` 切片运算 | §2 | ❌ 仅类型语法有占位 | 高 |
| `arena { ... }` 帧级分配 | §2 / §6 | ❌ 运行时已有（`tools/rosoto_mem.py`），**缺语法与降级** | 中 |
| `spawn` / `join` / `chan[T]` | §4 | ❌ 运行时已有（`tools/rosoto_mt.py`），**缺语法与降级** | 中 |
| 泛型 / 接口 `interface` | §2 | ❌ 未实现 | 中 |
| 所有权 + 借用检查（`&T` / `&mut T`） | §2 | ❌ 未实现 | 中 |
| `@simd` / `@no_preempt` / `@rc[T]` / `@extern("C")` / `@import_c` | §2/§4/§6 | ❌ 未实现 | 中 |
| **结构体返回值** | §2 | ⛔ **显式报错**（v0.2 边界，见 §4） | 中 |
| `print(结构体)` | — | ⛔ 显式报错，要求打印具体字段 | 低 |

### 2.2 后端 / 平台

| 项 | 现状 |
|---|---|
| Windows x86_64（PE/COFF + IOCP） | ❌ 未做 |
| macOS/iOS（Mach-O + kqueue） | ❌ 未做 |
| Web（wasm64） | ❌ 未做 |
| SIMD 自动向量化（SSE2→AVX2） | ❌ 未做（loop_sum 518ms vs gcc 158ms 的差距就在这里） |
| 尾调用消除 / LTO / 热重载 | ❌ 未做 |

### 2.3 工程化

| 项 | 现状 |
|---|---|
| `rosoto test` 的 `--target both` 交叉验证 | CLI 有壳，未接到新特性上 |
| `rosoto bench` 基线对比 | CLI 有壳，未跑过真实基线 |
| 格式化器幂等性对新语法（struct）的覆盖 | `rosoto_fmt.py` 未适配 `struct` 声明块 |
| Windows 侧执行验证 | 远端机器**无 gcc/clang**，只能做源码同步；执行级验证须在 Linux 侧 |

---

## 3. 差什么（阻塞项 / 需要的输入）

1. **缺 ARM64 / Windows 真机**：`rosoto_arm64.py` 目前只有「ELF 结构 + 自研模拟器执行级」验证，
   要上真机需要 aarch64 主机或 qemu-user（本机都没有）。
2. **缺 Windows 工具链**：远端 `C:\Users\43551\Desktop\Rosoto` 上没有 `gcc/clang/zig/cl`，
   C 后端与 `tests/*.sh`（bash）在那边跑不了，只能在 Linux 侧编译验证。
3. **缺 `enum`/`match` 的设计定稿**：枚举的内存布局（tag + payload 的槽位数/对齐）
   会直接影响 `frameaddr` 的槽位分配，建议先定稿再动代码。
4. **缺跨平台 IO 后端的实测环境**（kqueue / IOCP 都需要对应主机）。

---

## 4. 写了多少（本轮产出统计）

| 类别 | 文件 | 行数 | 说明 |
|---|---|---|---|
| 前端 + C 后端 | `tools/rosoto.py` | 1464 | 词法/语法/类型/C99 转译（新增 struct/break/continue） |
| 自研 x86_64 后端 | `tools/rosoto_native.py` | 2195 | RosIR/优化/寄存器分配/指令编码/裸 ELF |
| 自研 AArch64 后端 | `tools/rosoto_arm64.py` | 571 | A64 编码器 + 发射层 |
| RosIR 优化器 | `tools/rosoto_opt.py` | 886 | 复制传播/CSE-GVN/LICM/展开/DCE/调度 |
| 回归脚本 | `tests/run_native_tests.sh` 等 | 1000 | 含自研 A64 模拟器 `a64_emu.py` |
| 新测试 | `tests/t8~t11.ros` | 165 | break/continue、struct、嵌套、并行共存 |
| 新示例 | `examples/game_loop|collatz|inventory|prime_parallel.ros` | 217 | 游戏/算法/工程/多核 |
| 文档 | `HANDOVER.md`（本文件） | — | 交接 |

**测试规模**：109 项（原生 33 / C 16 / corelib 34 / uring 26），全绿。
**双后端交叉验证**：t8/t9/t10/t11 + 4 个新示例，x86_64 / AArch64 / C 三条链输出逐字节 diff 为 0。

---

## 5. 需要写什么（下一轮的活）

按「性价比」排序，建议下一轮按这个顺序：

1. **`enum` + `match`（含穷尽性检查）** —— 语言辨识度最高的一块。
   设计要点：枚举 = tag 字段 + payload 槽位（复用本轮的结构体槽位模型）；
   `match` 降级为比较链 + 跳转表；穷尽性在编译期对已声明变体做集合差。
   → 落点：`tools/rosoto.py`（parse + C codegen）、`tools/rosoto_native.py`（Lower）、
   `tools/rosoto_arm64.py`（无改动，复用 RosIR）。
2. **`arena { ... }` 语法接入** —— 运行时 `tools/rosoto_mem.py` 已经写好了（bump 分配器 + 帧回收），
   只差语法 + 降级，是**最便宜的一块**。
3. **`spawn` / `join` / `chan[T]` 语法接入** —— 同上，运行时 `tools/rosoto_mt.py` 已写好。
4. **`option[T]` / `result[T,E]` + `?`** —— 让错误传播落地，SPEC §3 的核心承诺。
5. **`map[K]V` / `[N]T` / `[]T` 运算** —— 补齐 §2 类型系统。
6. **`rosoto_fmt.py` 适配 `struct`**，并把 `rosoto test` 接到新特性上。
7. **性能**：loop_sum 518ms vs gcc -O2 158ms 的差距 = 自动向量化 + 指令调度（v0.3 目标）。
8. **平台**：Windows PE/COFF + IOCP，macOS Mach-O + kqueue。

---

## 6. 怎么接着干（开工步骤）

```bash
# 1. 同步远端源码到工作区（本轮已推到 C:\Users\43551\Desktop\Rosoto\rosoto）
# 2. 跑全量回归，确认 109 项全绿
bash tests/run_native_tests.sh   # 33
bash tests/run_tests.sh          # 16
bash tests/test_corelib.sh       # 34
bash tests/test_uring.sh         # 26

# 3. 单文件快速试跑（三条链）
python3 tools/rosoto_native.py run examples/game_loop.ros   # 自研 x86_64 -> 裸 ELF64
python3 tools/rosoto_arm64.py  build examples/game_loop.ros -o build/x_a64   # 自研 AArch64
python3 tools/rosoto.py        run examples/game_loop.ros   # Rosoto -> C99 -> cc

# 4. 看 IR（调编译器必用）
python3 tools/rosoto_native.py build tests/t11.ros -o /dev/null --dump-ir --no-opt
```

**改自研后端时的注意事项（血泪教训，务必先读）：**

- RosIR 是**非 SSA**：同一 vreg 可多次定义、变量原地更新、无 phi。
  任何 pass 都要对「vreg 多次定义」保守处理，否则会把循环携带值当成不变量。
- 新增 RosIR 指令时，**必须同时改这 5 处**，漏一处就是隐性错编：
  1. `tools/rosoto_native.py` 的 `_map_ins`（内联重命名）
  2. `tools/rosoto_opt.py` 的 `vreg_mentions`（def/use）+ `PURE`（可否被 DCE/CSE/LICM）
  3. `tools/rosoto_native.py` 的 x86_64 `gen_instr`
  4. `tools/rosoto_arm64.py` 的 A64 `gen_instr`
  5. `allocate()` 若该指令有特殊寄存器约束
- **parfor worker 永远不能被内联**（`Fn.no_inline = True`）——它跑在另一个栈上。
- **帧槽的字序号递增方向必须与 `base + idx*8` 一致**，否则字段反向错位、甚至写穿返回地址。
- 结构体局部量走**栈帧**（`frameaddr`），不要退化到全局静态区，否则递归/多线程必炸。

---

## 7. 本轮改动的文件清单（供 diff/回滚）

```
tools/rosoto.py        词法/语法/类型/C 转译   （+ struct/break/continue）
tools/rosoto_native.py 自研 x86_64             （+ frameaddr、struct 降级、两处编译器 bug 修复）
tools/rosoto_arm64.py  自研 AArch64            （+ frameaddr）
tools/rosoto_opt.py    RosIR 优化器            （+ frameaddr 的 def/use 与 PURE 归类）
tests/run_native_tests.sh                       （15 -> 33 项）
tests/run_tests.sh                              （8 -> 16 项）
tests/t8.ros  break/continue                    新增
tests/t9.ros  struct 基础 + 值语义              新增
tests/t10.ros struct 帧槽 × parfor 共存         新增（抓到内联 bug）
tests/t11.ros 嵌套结构体布局                    新增（抓到 frameaddr 方向 bug）
examples/game_loop.ros      游戏                新增
examples/collatz.ros        算法                新增
examples/inventory.ros      工程建模            新增
examples/prime_parallel.ros 多核                新增
```
